# SCPP — HSE Control

Application de gestion des risques et anomalies HSE pour la SCPP (échafaudage, peinture,
sablage, travaux sur corde, maintenance navale, mécanique, électricité, soudure, engins &
circulation, manutention, bureau/ergonomie).

C'est une **PWA** (Progressive Web App) : elle s'installe comme une app sur téléphone/PC
et peut aussi être publiée comme véritable application Android.

## Contenu du dossier

```
index.html            → l'application (page unique)
manifest.json          → métadonnées de l'app (nom, icônes, couleurs, captures d'écran)
sw.js                   → service worker (fonctionnement hors-ligne basique)
icons/                  → icônes de l'app (192, 512, maskable, apple-touch, favicon)
screenshots/            → captures d'écran réelles de l'app (pour la fiche Play Store)
```

## ⚠️ Important : stockage des données

Les données (anomalies, rondes, permis) sont enregistrées avec `localStorage`,
**dans le navigateur de chaque appareil**. Cela veut dire :
- Les données ne sont **pas partagées** entre plusieurs téléphones/PC.
- Vider le cache du navigateur ou désinstaller l'app efface les données.
- Pour une vraie base de données partagée entre toute l'équipe (multi-appareils),
  il faudra ajouter un backend plus tard (ex. Firebase, Supabase) — dites-le-moi si
  vous voulez que je prépare cette étape.

## 1. Déployer sur GitHub Pages

### ⚠️ Faites cette étape depuis un ordinateur, pas un téléphone

Sur mobile, l'upload GitHub ne conserve pas toujours les sous-dossiers (`icons/`,
`screenshots/`) — c'est ce qui a causé les erreurs "Fix the links to your icons" sur
PWABuilder. Sur ordinateur, le glisser-déposer d'un dossier entier fonctionne
correctement et conserve la structure.

1. Allez sur **github.com** et créez un compte (gratuit) si besoin.
2. Cliquez **+ → New repository**, donnez un nom (ex. `scpp-hse-app`) → **Public** →
   **Create repository**.
3. Sur la page du dépôt, cliquez **Add file → Upload files**.
4. Dézippez `scpp-hse-app.zip` sur votre ordinateur. Vous obtenez un dossier
   `scpp-hse-app` contenant `index.html`, `manifest.json`, `sw.js`, `icons/`,
   `screenshots/`.
5. **Ouvrez ce dossier** dans l'explorateur de fichiers, **sélectionnez tout son
   contenu** (les fichiers ET les dossiers `icons` et `screenshots`, mais pas le
   dossier `scpp-hse-app` lui-même), puis **glissez-déposez le tout** dans la zone
   d'upload de GitHub. `index.html` doit finir à la racine du dépôt, pas dans un
   sous-dossier.
6. Cliquez **Commit changes**.
7. Vérifiez : dans le dépôt, vous devez voir `index.html`, `manifest.json`, `sw.js`,
   et deux dossiers `icons` et `screenshots` — chacun avec ses fichiers dedans.
8. **Settings → Pages → Source** : choisissez **Deploy from a branch**, branche
   `main`, dossier `/ (root)` → **Save**.
9. Attendez 1–2 minutes puis ouvrez l'URL fournie, du type :
   `https://votre-compte.github.io/scpp-hse-app/`

### Vérification anti-erreur

Avant de retourner sur PWABuilder, testez ces liens dans le navigateur (doivent
afficher une image, pas une erreur 404) :
```
https://votre-compte.github.io/scpp-hse-app/icons/icon-192.png
https://votre-compte.github.io/scpp-hse-app/icons/icon-512.png
https://votre-compte.github.io/scpp-hse-app/manifest.json
```

## 2. Créer l'application Android (fichier .apk / .aab)

1. Allez sur **https://www.pwabuilder.com**
2. Collez l'URL de votre site GitHub Pages → **Start**.
3. Le score du Manifest doit maintenant afficher un résultat bien plus élevé, sans les
   erreurs de liens d'icônes.
4. Cliquez **Package for stores** → choisissez **Android**.
5. Laissez les options par défaut → **Generate** / **Download**.
6. Vous recevez un `.apk` (installable directement, "sideload") et/ou un `.aab`
   (pour publier sur le Google Play Store).

### Alternative en ligne de commande : Bubblewrap

```bash
npm install -g @bubblewrap/cli
bubblewrap init --manifest="https://votre-compte.github.io/scpp-hse-app/manifest.json"
bubblewrap build
```

## 3. Installer l'APK sur un téléphone

1. Transférez le `.apk` sur le téléphone (câble, e-mail, Drive...).
2. Ouvrez le fichier — autorisez "Installer des applications inconnues" si demandé.
3. L'app s'installe avec l'icône et le nom SCPP.

## 4. Mettre à jour l'application plus tard

Toute modification de `index.html` suffit : re-poussez le fichier sur GitHub, le site
se met à jour automatiquement, et l'app Android (TWA) affiche la dernière version en
ligne — pas besoin de republier l'APK à chaque changement de contenu.
